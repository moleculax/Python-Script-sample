## Recommended learning resources

* [The Python Tutorial](https://docs.python.org/3/tutorial/)
* [Learn Python The Hard Way](http://learnpythonthehardway.org/book/)
* [Think Python](http://www.greenteapress.com/thinkpython/html/index.html)
* [The Python Library Reference](https://docs.python.org/3/library/index.html)
