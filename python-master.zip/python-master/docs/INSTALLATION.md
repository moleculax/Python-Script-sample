## Installing Python

If Python isn't already available on your system follow the instructions at [the Hitchhiker's Guide to Python](http://docs.python-guide.org/en/latest/starting/installation/) to install Python on your computer.

Exercism currently supports Python2.7 and Python 3.4+.
