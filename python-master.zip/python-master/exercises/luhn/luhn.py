class Luhn(object):
    def __init__(self, card_num):
        pass

    def is_valid(self):
        pass
