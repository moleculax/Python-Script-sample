def on_square(integer_number):
    pass


def total_after(integer_number):
    pass
