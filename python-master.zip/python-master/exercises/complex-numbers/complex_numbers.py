class ComplexNumber(object):
    def __init__(self, real, imaginary):
        pass

    def __add__(self, other):
        pass

    def __mul__(self, other):
        pass

    def __sub__(self, other):
        pass

    def __truediv__(self, other):
        pass

    def __abs__(self):
        pass

    def conjugate(self):
        pass

    def exp(self):
        pass
