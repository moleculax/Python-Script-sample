
class ConnectGame:
    def __init__(self, board):
        pass

    def get_winner(self):
        pass
