def recite(start, take=1):
    pass
