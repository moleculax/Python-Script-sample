def numeral(number):
    pass
