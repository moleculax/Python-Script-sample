def calculate(question):
    pass
