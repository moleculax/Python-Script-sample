def triplets_with_sum(sum_of_triplet):
    pass


def triplets_in_range(range_start, range_end):
    pass


def is_triplet(triplet):
    pass
