def find_anagrams(word, candidates):
    pass
