def rows(row_count):
    pass
