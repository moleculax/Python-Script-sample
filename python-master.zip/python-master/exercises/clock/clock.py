class Clock(object):
    def __init__(self, hour, minute):
        pass

    def __repr__(self):
        pass

    def __eq__(self, other):
        pass

    def __add__(self, minutes):
        pass

    def __sub__(self, minutes):
        pass
