def transform(legacy_data):
    pass
