def make_diamond(letter):
    pass
