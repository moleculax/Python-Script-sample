def sieve(limit):
    pass
