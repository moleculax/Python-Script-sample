def count(strand, nucleotide):
    pass


def nucleotide_counts(strand):
    pass
