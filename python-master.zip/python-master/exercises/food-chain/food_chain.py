def recite(start_verse, end_verse):
    pass
