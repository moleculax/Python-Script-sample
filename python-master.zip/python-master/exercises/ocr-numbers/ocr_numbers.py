def convert(input_grid):
    pass
