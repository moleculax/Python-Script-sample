class CustomSet(object):
    def __init__(self, elements=[]):
        pass

    def isempty(self):
        pass

    def __contains__(self, element):
        pass

    def issubset(self, other):
        pass

    def isdisjoint(self, other):
        pass

    def __eq__(self, other):
        pass

    def add(self, element):
        pass

    def intersection(self, other):
        pass

    def __sub__(self, other):
        pass

    def __add__(self, other):
        pass
