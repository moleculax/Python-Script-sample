def check_lists(first_list, second_list):
    pass
