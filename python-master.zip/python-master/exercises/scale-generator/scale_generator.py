class Scale(object):
    def __init__(self, tonic):
        pass

    def chromatic(self):
        pass

    def interval(self, intervals):
        pass
