def tally(tournament_results):
    pass
