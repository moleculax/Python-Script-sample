def is_pangram(sentence):
    pass
