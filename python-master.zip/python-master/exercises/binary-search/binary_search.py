def binary_search(list_of_numbers, number):
    pass
