def trinary(string):
    pass
