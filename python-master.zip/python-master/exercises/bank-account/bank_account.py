class BankAccount(object):
    def __init__(self):
        pass

    def get_balance(self):
        pass

    def open(self):
        pass

    def deposit(self, amount):
        pass

    def withdraw(self, amount):
        pass

    def close(self):
        pass
