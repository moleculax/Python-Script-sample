def rotate(text, key):
    pass
