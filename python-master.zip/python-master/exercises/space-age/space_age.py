class SpaceAge(object):
    def __init__(self, seconds):
        pass
