def encode(numbers):
    pass


def decode(bytes_):
    pass
