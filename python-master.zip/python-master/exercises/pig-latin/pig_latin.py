def translate(text):
    pass
