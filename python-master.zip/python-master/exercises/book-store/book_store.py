def calculate_total(books):
    pass
