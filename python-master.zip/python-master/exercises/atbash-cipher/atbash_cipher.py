def encode(plain_text):
    pass


def decode(ciphered_text):
    pass
