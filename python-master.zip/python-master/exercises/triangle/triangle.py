def is_equilateral(sides):
    pass


def is_isosceles(sides):
    pass


def is_scalene(sides):
    pass
