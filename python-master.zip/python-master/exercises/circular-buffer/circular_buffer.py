class BufferFullException(Exception):
    pass


class BufferEmptyException(Exception):
    pass


class CircularBuffer(object):
    def __init__(self, capacity):
        pass

    def read(self):
        pass

    def write(self, data):
        pass

    def overwrite(self, data):
        pass

    def clear(self):
        pass
