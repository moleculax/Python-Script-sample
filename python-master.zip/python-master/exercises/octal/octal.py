def parse_octal(digits):
    pass
