class Garden(object):
    def __init__(self, diagram, students):
        pass
