def keep(sequence, predicate):
    pass


def discard(sequence, predicate):
    pass
