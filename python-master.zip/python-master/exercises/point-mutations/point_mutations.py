def hamming_distance(dna_strand_1, dna_strand_2):
    pass
