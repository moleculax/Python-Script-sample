class Character:
    def __init__(self):
        pass
