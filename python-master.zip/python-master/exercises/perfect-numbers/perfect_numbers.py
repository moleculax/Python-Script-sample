def classify(number):
    pass
