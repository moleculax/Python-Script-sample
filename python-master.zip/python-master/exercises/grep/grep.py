def grep(pattern, files, flags=''):
    pass
