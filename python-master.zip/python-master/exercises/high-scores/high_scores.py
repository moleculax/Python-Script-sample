class HighScores(object):
    def __init__(self, scores):
        pass
