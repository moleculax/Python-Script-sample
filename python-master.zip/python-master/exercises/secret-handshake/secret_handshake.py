def handshake(code):
    pass


def secret_code(actions):
    pass
