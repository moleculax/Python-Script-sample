def word_count(phrase):
    pass
