def hey(phrase):
    pass
