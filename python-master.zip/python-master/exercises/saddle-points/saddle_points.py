def saddle_points(matrix):
    pass
