def square_of_sum(count):
    pass


def sum_of_squares(count):
    pass


def difference(count):
    pass
