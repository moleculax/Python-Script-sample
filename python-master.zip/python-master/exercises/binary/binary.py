def parse_binary(binary_string):
    pass
