def reverse(text=''):
    return text[::-1]
