def reverse(text):
    pass
