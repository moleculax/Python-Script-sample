def score(word):
    pass
