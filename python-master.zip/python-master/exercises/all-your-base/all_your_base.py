def rebase(input_base, digits, output_base):
    pass
