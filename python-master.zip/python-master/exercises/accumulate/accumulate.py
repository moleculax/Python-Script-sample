def accumulate(collection, operation):
    pass
