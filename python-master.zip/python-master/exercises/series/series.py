def slices(series, length):
    pass
