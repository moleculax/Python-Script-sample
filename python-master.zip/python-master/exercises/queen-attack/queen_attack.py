class Queen(object):
    def __init__(self, row, column):
        pass

    def can_attack(self, another_queen):
        pass
