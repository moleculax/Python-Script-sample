class BowlingGame(object):
    def __init__(self):
        pass

    def roll(self, pins):
        pass

    def score(self):
        pass
