def encode(plain_text, a, b):
    pass


def decode(ciphered_text, a, b):
    pass
