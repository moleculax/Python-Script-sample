def calculate(text_input):
    pass
