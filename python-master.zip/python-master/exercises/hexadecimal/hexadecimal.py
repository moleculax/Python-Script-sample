def hexa(hex_string):
    pass
