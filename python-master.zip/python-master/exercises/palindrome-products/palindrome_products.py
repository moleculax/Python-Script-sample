def largest_palindrome(max_factor, min_factor):
    pass


def smallest_palindrome(max_factor, min_factor):
    pass
