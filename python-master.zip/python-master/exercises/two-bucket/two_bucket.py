def measure(bucket_one, bucket_two, goal, start_bucket):
    pass
