def is_paired(input_string):
    pass
