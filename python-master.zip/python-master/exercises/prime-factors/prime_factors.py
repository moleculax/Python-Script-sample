def prime_factors(natural_number):
    pass
