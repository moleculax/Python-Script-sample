def sum_of_multiples(limit, multiples):
    pass
