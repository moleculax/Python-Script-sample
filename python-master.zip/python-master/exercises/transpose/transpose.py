def transpose(input_lines):
    pass
