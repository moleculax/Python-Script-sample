def flatten(iterable):
    pass
