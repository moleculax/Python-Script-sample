def chain(dominoes):
    pass
