def encode(plain_text):
    pass
