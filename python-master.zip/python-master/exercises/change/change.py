def find_minimum_coins(total_change, coins):
    pass
