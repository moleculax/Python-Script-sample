def count(ascii_diagram):
    pass
