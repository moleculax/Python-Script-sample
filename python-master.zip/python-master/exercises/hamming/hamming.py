def distance(strand_a, strand_b):
    pass
