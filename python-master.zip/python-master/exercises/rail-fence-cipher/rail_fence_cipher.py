def encode(message, rails):
    pass


def decode(encoded_message, rails):
    pass
