class Phone(object):
    def __init__(self, phone_number):
        pass
