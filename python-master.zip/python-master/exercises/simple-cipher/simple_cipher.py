class Cipher(object):
    def __init__(self, key=None):
        pass

    def encode(self, text):
        pass

    def decode(self, text):
        pass
