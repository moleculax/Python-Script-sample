def proteins(strand):
    pass
