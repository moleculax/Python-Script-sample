class StackUnderflowError(Exception):
    pass


def evaluate(input_data):
    pass
