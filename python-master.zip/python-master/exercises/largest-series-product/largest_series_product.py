def largest_product(series, size):
    pass
