def add_gigasecond(moment):
    pass
