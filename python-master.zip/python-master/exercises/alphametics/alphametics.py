def solve(puzzle):
    pass
