def say(number):
    pass
