def meetup_day(year, month, day_of_the_week, which):
    pass
