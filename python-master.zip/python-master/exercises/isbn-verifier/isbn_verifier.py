def verify(isbn):
    pass
