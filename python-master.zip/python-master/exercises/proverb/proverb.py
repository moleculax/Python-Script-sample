def proverb(rhyme_items):
    pass
