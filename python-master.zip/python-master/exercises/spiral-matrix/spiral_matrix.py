def spiral(size):
    pass
