class RestAPI(object):
    def __init__(self, database=None):
        pass

    def get(self, url, payload=None):
        pass

    def post(self, url, payload=None):
        pass
