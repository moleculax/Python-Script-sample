def collatz_steps(number):
    pass
