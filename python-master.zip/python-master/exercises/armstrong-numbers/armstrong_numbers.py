def is_armstrong(number):
    pass
