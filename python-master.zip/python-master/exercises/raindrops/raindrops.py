def raindrops(number):
    pass
