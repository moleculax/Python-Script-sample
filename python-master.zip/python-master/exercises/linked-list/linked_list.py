class Node(object):
    def __init__(self, value, succeeding=None, previous=None):
        pass


class LinkedList(object):
    def __init__(self):
        pass
