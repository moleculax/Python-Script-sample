def to_rna(dna_strand):
    pass
