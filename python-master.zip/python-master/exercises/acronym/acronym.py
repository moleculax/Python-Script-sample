def abbreviate(words):
    pass
