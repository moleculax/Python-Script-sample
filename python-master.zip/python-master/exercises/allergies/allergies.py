class Allergies(object):

    def __init__(self, score):
        pass

    def is_allergic_to(self, item):
        pass

    @property
    def lst(self):
        pass
