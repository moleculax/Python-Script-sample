def best_hands(hands):
    pass
