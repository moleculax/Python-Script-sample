def nth_prime(positive_number):
    pass
